import { Component, OnInit } from '@angular/core';
declare var $:any;

@Component({
  selector: 'app-organizer',
  templateUrl: './organizer.component.html',
  styleUrls: ['./organizer.component.css']
})
export class OrganizerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    $(document).ready(function(){
      $('select').formSelect();
    });
  }

}
